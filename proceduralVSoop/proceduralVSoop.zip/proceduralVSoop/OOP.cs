﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proceduralVSoop
{
    class OOP
    {
        public void printHelloWorld()
        {
            Console.WriteLine("Hello World!");
        }

        public int sumAB(int a, int b)
        {
            int result = a + b;
            return result;
        }

    }
}
